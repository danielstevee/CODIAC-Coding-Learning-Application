from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
import json

Builder.load_file("app/ui/profilbarulagi.kv")

class ProfilBaruLagiScreen(MDScreen):
    pass
    
