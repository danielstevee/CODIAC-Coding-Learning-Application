from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

Builder.load_file("app/ui/task_i.kv")

class TaskScreen_i(MDScreen):
    pass
    