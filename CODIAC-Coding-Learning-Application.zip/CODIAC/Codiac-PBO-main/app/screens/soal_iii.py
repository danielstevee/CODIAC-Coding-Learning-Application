from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/soal_iii.kv")

class SoalScreen_iii(MDScreen):
    pass
    