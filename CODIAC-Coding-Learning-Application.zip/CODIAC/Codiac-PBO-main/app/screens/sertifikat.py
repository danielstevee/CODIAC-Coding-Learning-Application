from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
import json

Builder.load_file("app/ui/sertifikat.kv")

class SertifikatScreen(MDScreen):
    pass
    