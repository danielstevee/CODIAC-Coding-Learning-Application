from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/course_v.kv")

class CourseScreen_v(MDScreen):
    pass
    