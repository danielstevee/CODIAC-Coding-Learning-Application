from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/course_i.kv")

class CourseScreen_i(MDScreen):
    pass
    