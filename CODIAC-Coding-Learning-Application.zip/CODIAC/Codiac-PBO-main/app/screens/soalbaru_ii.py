from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/soalbaru_ii.kv")

class SoalBaruScreen_ii(MDScreen):
    pass
    