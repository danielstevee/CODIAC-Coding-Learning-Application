from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/pilihcourse.kv")

class PilihCourse(MDScreen):
    pass
    