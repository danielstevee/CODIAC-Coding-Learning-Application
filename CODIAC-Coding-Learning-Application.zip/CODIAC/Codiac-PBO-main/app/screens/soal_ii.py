from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/soal_ii.kv")

class SoalScreen_ii(MDScreen):
    pass
    