from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
import json

Builder.load_file("app/ui/scorebarulagi.kv")

class ScoreBaruLagiScreen(MDScreen):
    pass
    