from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/course_ii.kv")

class CourseScreen_ii(MDScreen):
    pass
    