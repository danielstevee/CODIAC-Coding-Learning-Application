from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/soalbaru_iii.kv")

class SoalBaruScreen_iii(MDScreen):
    pass
    