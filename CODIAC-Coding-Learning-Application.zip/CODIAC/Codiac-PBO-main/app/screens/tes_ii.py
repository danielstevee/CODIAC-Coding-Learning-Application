from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/tes_ii.kv")

class TesScreen_ii(MDScreen):
    pass
    