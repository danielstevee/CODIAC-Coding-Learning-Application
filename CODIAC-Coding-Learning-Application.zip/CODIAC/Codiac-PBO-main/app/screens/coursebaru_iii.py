from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/coursebaru_iii.kv")

class CoursebaruScreen_iii(MDScreen):
    pass
    