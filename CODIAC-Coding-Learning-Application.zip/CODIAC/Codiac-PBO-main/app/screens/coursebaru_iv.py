from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/coursebaru_iv.kv")

class CoursebaruScreen_iv(MDScreen):
    pass
    