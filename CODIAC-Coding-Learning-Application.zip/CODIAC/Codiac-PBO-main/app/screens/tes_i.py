from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

# Memuat file KV
Builder.load_file("app/ui/tes_i.kv")

class TesScreen_i(MDScreen):
    pass
    