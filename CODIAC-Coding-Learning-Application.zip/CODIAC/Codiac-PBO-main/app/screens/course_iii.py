from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/course_iii.kv")

class CourseScreen_iii(MDScreen):
    pass
    