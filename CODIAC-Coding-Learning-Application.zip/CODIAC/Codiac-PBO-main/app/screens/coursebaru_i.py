from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/coursebaru_i.kv")

class CoursebaruScreen_i(MDScreen):
    pass
    