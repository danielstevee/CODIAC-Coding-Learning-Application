from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


Builder.load_file("app/ui/coursebaru_ii.kv")

class CoursebaruScreen_ii(MDScreen):
    pass
    