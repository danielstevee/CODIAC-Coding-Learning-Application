from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
import json

Builder.load_file("app/ui/profil.kv")

class ProfilScreen(MDScreen):
    pass
    