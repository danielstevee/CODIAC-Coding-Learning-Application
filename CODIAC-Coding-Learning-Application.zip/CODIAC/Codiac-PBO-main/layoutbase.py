#from kivy.uix.screenmanager import ScreenManager
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.clock import Clock
from app.screens.home import HomeScreen
from app.screens.bookmark import BookmarkScreen
from app.screens.timer import TimerScreen
from app.screens.selesaivariabel import SelesaiVariabelScreen
from app.screens.profil import ProfilScreen
from app.screens.profilbaru import ProfilBaruScreen
from app.screens.profilbarulagi import ProfilBaruLagiScreen



Builder.load_file("layoutbase.kv")
# Builder.load_file("app/ui/home.kv")
# Builder.load_file("app/ui/bookmark.kv")
# Builder.load_file("app/ui/timer.kv")

class LayoutBase(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_once(self.load_screen)
        
    def load_screen(self, dt):
        self.ids.screen_manager.add_widget(HomeScreen(name="home"))
        self.ids.screen_manager.add_widget(BookmarkScreen(name="bookmark"))
        self.ids.screen_manager.add_widget(TimerScreen(name="timer"))
        self.ids.screen_manager.add_widget(SelesaiVariabelScreen(name="selesaivariabel"))   
        self.ids.screen_manager.add_widget(ProfilScreen(name="profil")) 
        self.ids.screen_manager.add_widget(ProfilBaruScreen(name="profilbaru")) 
        self.ids.screen_manager.add_widget(ProfilBaruLagiScreen(name="profilbarulagi"))
        self.ids.screen_manager.current = "home"
        