from kivymd.app import MDApp
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager
from kivy.utils import get_color_from_hex
from kivy.core.text import LabelBase
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
from app.screens.login import LoginScreen
from app.screens.register import RegisterScreen
from app.screens.splash import SplashScreen
from app.screens.course_i import CourseScreen_i
from app.screens.course_ii import CourseScreen_ii
from app.screens.course_iii import CourseScreen_iii
from app.screens.course_iv import CourseScreen_iv
from app.screens.course_v import CourseScreen_v
from app.screens.task_i import TaskScreen_i
from app.screens.pilihcourse import PilihCourse
from app.screens.teskemampuan import TesKemampuanScreen
from app.screens.soal_i import SoalScreen_i
from app.screens.soal_ii import SoalScreen_ii
from app.screens.soal_iii import SoalScreen_iii
from app.screens.soal_iv import SoalScreen_iv
from app.screens.soal_v import SoalScreen_v
from app.screens.timer import TimerScreen
from app.screens.sertifikat import SertifikatScreen
from app.screens.coursebaru_i import CoursebaruScreen_i
from app.screens.coursebaru_ii import CoursebaruScreen_ii
from app.screens.coursebaru_iii import CoursebaruScreen_iii
from app.screens.coursebaru_iv import CoursebaruScreen_iv
from app.screens.coursebaru_v import CoursebaruScreen_v
from app.screens.selesaimisi import SelesaiMisiScreen
from app.screens.selesaivariabel import SelesaiVariabelScreen
from app.screens.soalbaru_i import SoalBaruScreen_i
from app.screens.soalbaru_ii import SoalBaruScreen_ii
from app.screens.soalbaru_iii import SoalBaruScreen_iii
from app.screens.soalbaru_iv import SoalBaruScreen_iv
from app.screens.soalbaru_v import SoalBaruScreen_v
from app.screens.scorebaru import ScoreBaruScreen
from app.screens.score import ScoreScreen
from app.screens.profil import ProfilScreen
from app.screens.profilbaru import ProfilBaruScreen
from app.screens.tes_i import TesScreen_i
from app.screens.tes_ii import TesScreen_ii
from app.screens.tes_iii import TesScreen_iii
from app.screens.tes_iv import TesScreen_iv
from app.screens.tes_v import TesScreen_v
from app.screens.scorebarulagi import ScoreBaruLagiScreen
from app.screens.selesaites import SelesaiTesScreen
from app.screens.profilbarulagi import ProfilBaruLagiScreen
from app.screens.studikasus import StudikasusScreen
from app.screens.teskemampuanlagi import TesKemampuanLagiScreen

from layoutbase import LayoutBase
from kivy.core.window import Window
from pathlib import Path
import json
#Untuk debugging windows
Window.size = (405, 720)
Window.minimum_width = 405
Window.minimum_height = 720
Window.left = 50
Window.top = 50

#Initialize Components 
Builder.load_file("app/components/custombtn.kv")
# Builder.load_file("root.kv")

#Global Path
logsess = Path("data/session.json")


class MainApp(MDApp):
    def build(self):
        self.load_font()
        self.theme_cls.primary_palette = "Indigo"
        self.theme_cls.theme_style = "Dark" 

        self.sm = ScreenManager()
        self.sm.add_widget(SplashScreen(name="splash"))
        self.sm.add_widget(LoginScreen(name="login"))
        self.sm.add_widget(RegisterScreen(name="register"))
        self.sm.add_widget(CourseScreen_i(name="course_i"))
        self.sm.add_widget(CourseScreen_ii(name="course_ii"))
        self.sm.add_widget(CourseScreen_iii(name="course_iii"))
        self.sm.add_widget(CourseScreen_iv(name="course_iv"))
        self.sm.add_widget(CourseScreen_v(name="course_v"))
        self.sm.add_widget(TaskScreen_i(name="task_i"))
        self.sm.add_widget(SoalBaruScreen_i(name="soalbaru_i"))
        self.sm.add_widget(SoalBaruScreen_ii(name="soalbaru_ii"))
        self.sm.add_widget(SoalBaruScreen_iii(name="soalbaru_iii"))
        self.sm.add_widget(SoalBaruScreen_iv(name="soalbaru_iv"))
        self.sm.add_widget(SoalBaruScreen_v(name="soalbaru_v"))
        self.sm.add_widget(CoursebaruScreen_i(name="coursebaru_i"))
        self.sm.add_widget(CoursebaruScreen_ii(name="coursebaru_ii"))
        self.sm.add_widget(CoursebaruScreen_iii(name="coursebaru_iii"))
        self.sm.add_widget(CoursebaruScreen_iv(name="coursebaru_iv"))
        self.sm.add_widget(CoursebaruScreen_v(name="coursebaru_v"))
        self.sm.add_widget(PilihCourse(name="pilihcourse"))
        self.sm.add_widget(SelesaiVariabelScreen(name="selesaivariabel"))
        self.sm.add_widget(TesScreen_i(name="tes_i"))
        self.sm.add_widget(TesScreen_ii(name="tes_ii"))
        self.sm.add_widget(TesScreen_iii(name="tes_iii"))
        self.sm.add_widget(TesScreen_iv(name="tes_iv"))
        self.sm.add_widget(TesScreen_v(name="tes_v"))
        self.sm.add_widget(ScoreBaruLagiScreen(name="scorebarulagi"))
        self.sm.add_widget(ScoreBaruScreen(name="scorebaru"))
        self.sm.add_widget(SoalScreen_i(name="soal_i"))
        self.sm.add_widget(SoalScreen_ii(name="soal_ii"))
        self.sm.add_widget(SoalScreen_iii(name="soal_iii"))
        self.sm.add_widget(SoalScreen_iv(name="soal_iv"))
        self.sm.add_widget(SoalScreen_v(name="soal_v"))
        self.sm.add_widget(LayoutBase(name="layoutbase"))
        self.sm.add_widget(TesKemampuanScreen(name="teskemampuan"))
        self.sm.add_widget(TesKemampuanLagiScreen(name="teskemampuanlagi"))
        self.sm.add_widget(ScoreScreen(name="score"))
        self.sm.add_widget(SertifikatScreen(name="sertifikat"))
        self.sm.add_widget(SelesaiMisiScreen(name="selesaimisi"))
        self.sm.add_widget(TimerScreen(name="timer"))
        self.sm.add_widget(ProfilScreen(name="profil"))
        self.sm.add_widget(ProfilBaruScreen(name="profilbaru"))
        self.sm.add_widget(ProfilBaruLagiScreen(name="profilbarulagi"))
        self.sm.add_widget(SelesaiTesScreen(name="selesaites"))
        self.sm.add_widget(StudikasusScreen(name="studikasus"))
        Clock.schedule_once(self.go_to_login, 4)

        return self.sm

    #Pindah ke LoginPage
    def go_to_login(self, dt):
        log = self.check_session()
        if log:
            self.sm.current = "layoutbase"    
        else: 
            self.sm.current = "login"
    
    #Pindah ke RegisterPage
    def go_to_reg(self):
        self.sm.current = "register"
    
    #Pindah ke HomePage
    def go_to_home(self):
        self.sm.current = "layoutbase"
        
    #Pindah ke pilih
    def go_to_pilih(self):
        self.sm.current = "pilihcourse"
        
    #Cek Sessions untuk AutoLogin
    def check_session(self):
        if logsess.exists():
            with open(logsess, "r") as f:
                data = json.load(f)
            log_true = data.get("is_logged_in")
            return log_true
        else:
            return False
    
    def bahasa(self, pilih):
        if logsess.exists():
            with open(logsess, "r") as f:
                data = json.load(f)
                
            data["bahasa"]= pilih
            
            with open(logsess, "w") as f:
                json.dump(data, f, indent=4)
            self.go_to_home()
        else:
            return
        
    def change(self, changeS):
        self.sm.current = changeS
    
    def change_screen(self, screen_name):
        MDApp.get_running_app().root.get_screen("layoutbase").ids.screen_manager.current = screen_name

    def show_snackbar(self):
        dialog = MDDialog(
            text="belum tersedia",
            buttons=[
                MDFlatButton(
                    text="Tutup",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()

    #Tambah Font Custom
    def load_font(self):
      LabelBase.register(
        name= "Poppins",
        fn_regular= "assets/fonts/Poppins-Regular.ttf",
        fn_bold= "assets/fonts/Poppins-Bold.ttf",
        )
      LabelBase.register(
        name= "Inter",
        fn_regular= "assets/fonts/Inter-VariableFont_opsz,wght.ttf",
        fn_italic= "assets/fonts/Inter-Italic-VariableFont_opsz,wght.ttf",
        )
      LabelBase.register(
        name="CourierPrime",
        fn_regular="assets/fonts/CourierPrime-Regular.ttf",
        fn_bold="assets/fonts/CourierPrime-Bold.ttf",
      )
    
    
if __name__ == '__main__':
    MainApp().run()